using UnityEngine;
using UnityEngine.Playables;

namespace CineShot.Core
{
    public class CineMixerBehaviour : PlayableBehaviour
    {
        CameraPose m_PrevPose;
        bool m_HasPrev;
        ShotAsset m_LatchedShot;
        CameraPose m_LatchPose;
        double m_LatchTime;
        bool m_HasLatch;
        const float k_BlendSeconds = 0.5f;

        public override void ProcessFrame(Playable playable, FrameData info, object playerData)
        {
            var rig = playerData as CineShotRig;
            if (rig == null)
                return;

            float dt = info.deltaTime;
            int n = playable.GetInputCount();
            PoseAccumulator acc = default(PoseAccumulator);
            float wsum = 0f;

            ShotAsset activeShot = null;
            ShotBlendMode activeBlend = ShotBlendMode.Cut;
            FocusMode focusMode = FocusMode.None;
            float focusHint = 10f;
            Transform focusTarget = null;
            HandheldLayer handheldLayer = default(HandheldLayer);
            bool matchFrame = false;
            CameraPose matchPose = CameraPose.Identity;

            for (int j = 0; j < n; j++)
            {
                float w = playable.GetInputWeight(j);
                if (w <= 0f)
                    continue;

                var input = (ScriptPlayable<CineShotBehaviour>)playable.GetInput(j);
                var beh = input.GetBehaviour();
                if (beh == null || beh.Clip == null || beh.Clip.shot == null)
                    continue;

                var clip = beh.Clip;
                var shot = clip.shot;
                double dur = input.GetDuration();
                float local = dur > 0.0 ? (float)(input.GetTime() / dur) : 0f;
                local = Mathf.Clamp01(local);

                float shaped = w;
                if (shaped <= 0f)
                    continue;

                RigParams rigParams;
                Vector3 composition;
                float fov, near, far, focusDistance;
                FocusMode mode;
                EasingAsset ignoredIn, ignoredOut;
                clip.overrides.ApplyTo(shot, out rigParams, out composition, out fov, out near, out far,
                    out mode, out focusDistance, out ignoredIn, out ignoredOut);

                Transform lookTr = clip.lookAt.Resolve(playable.GetGraph().GetResolver());
                Transform followTr = clip.follow.Resolve(playable.GetGraph().GetResolver());

                var look = rig.SampleLookAt(lookTr, clip.overrides.ResolveLookOffset(shot), dt);
                var follow = rig.SampleFollow(followTr, clip.overrides.ResolveFollowOffset(shot), dt);

                var ctx = new ShotContext
                {
                    LocalTime = (float)input.GetTime(),
                    Duration = (float)dur,
                    DeltaTime = dt,
                    LookAt = look,
                    Follow = follow,
                    CompositionOffset = composition,
                    Seed = shot.Seed,
                    Spline = clip.spline
                };

                var pose = CameraPose.Identity;
                pose.Fov = fov;
                pose.NearClip = near;
                pose.FarClip = far;
                pose.FocusDistance = focusDistance;
                SolverDispatch.Solve(shot.rigKind, in ctx, in rigParams, ref pose);

                if (clip.blendMode == ShotBlendMode.MatchFrame && shot.matchPoint.valid && local < 0.02f)
                {
                    matchFrame = true;
                    matchPose.Position = shot.matchPoint.position;
                    matchPose.Rotation = shot.matchPoint.rotation;
                    matchPose.Fov = shot.matchPoint.fov > 1f ? shot.matchPoint.fov : pose.Fov;
                    matchPose.NearClip = pose.NearClip;
                    matchPose.FarClip = pose.FarClip;
                    matchPose.FocusDistance = pose.FocusDistance;
                }

                acc.Add(in pose, shaped);
                wsum += shaped;

                if (shaped >= wsum * 0.5f || activeShot == null)
                {
                    activeShot = shot;
                    activeBlend = clip.blendMode;
                    focusMode = mode;
                    focusHint = focusDistance;
                    focusTarget = lookTr != null ? lookTr : followTr;
                    handheldLayer = shot.handheld;
                }
            }

            if (wsum <= 0f)
            {
                rig.SetActiveShot(null);
                rig.ReleasePose(dt);
                return;
            }

            rig.SetActiveShot(activeShot);

            CameraPose blended;
            if (!acc.TryBuild(out blended))
            {
                rig.ReleasePose(dt);
                return;
            }

            if (matchFrame && m_HasPrev)
            {
                blended.Position = matchPose.Position;
                blended.Rotation = matchPose.Rotation;
                blended.Fov = matchPose.Fov;
            }
            else if (activeBlend == ShotBlendMode.Blend)
            {
                if (activeShot != m_LatchedShot)
                {
                    m_LatchPose = m_HasPrev ? m_PrevPose : blended;
                    m_LatchTime = playable.GetTime();
                    m_LatchedShot = activeShot;
                    m_HasLatch = m_HasPrev;
                }
                if (m_HasLatch)
                {
                    float elapsed = (float)(playable.GetTime() - m_LatchTime);
                    if (elapsed >= 0f && elapsed < k_BlendSeconds)
                    {
                        float u = elapsed / k_BlendSeconds;
                        u = u * u * (3f - 2f * u);
                        blended = CameraPose.Lerp(m_LatchPose, blended, u);
                    }
                }
            }

            if (handheldLayer.enabled)
                HandheldSolver.SolveStatic(
                    new ShotContext { LocalTime = (float)playable.GetTime(), Seed = activeShot != null ? activeShot.Seed : 0 },
                    in handheldLayer.parameters,
                    ref blended);

            Transform focusTr = focusTarget;
            rig.SubmitPose(in blended, dt, focusHint, focusMode, focusTr);
            m_PrevPose = blended;
            m_HasPrev = true;
        }
    }
}
