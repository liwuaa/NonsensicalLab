using UnityEngine;

namespace CineShot.Core
{
    [ExecuteAlways]
    [DisallowMultipleComponent]
    public sealed class CineShotRig : MonoBehaviour
    {
        [SerializeField] Component m_OutputVcam;
        [SerializeField] Component m_GameVcam;
        [SerializeField] FocusProfile m_FocusProfile;
        [SerializeField] float m_MinTargetDistance = 0.35f;
        [SerializeField] Camera m_FallbackCamera;

        readonly FocusSolver m_FocusSolver = new FocusSolver();
        readonly FocusRequest[] m_FocusBuffer = new FocusRequest[8];
        ICameraOutput m_Output = NullCameraOutput.Instance;
        IFocusOutput m_FocusOutput = NullFocusOutput.Instance;
        CameraPose m_LastPose = CameraPose.Identity;
        bool m_HasPose;
        ShotAsset m_ActiveShot;
        Vector3 m_LookLast;
        Vector3 m_FollowLast;
        bool m_HasLookLast;
        bool m_HasFollowLast;

        public FocusProfile FocusProfile { get { return m_FocusProfile; } }
        public ICameraOutput Output { get { return m_Output; } }
        public CameraPose LastPose { get { return m_LastPose; } }
        public bool HasPose { get { return m_HasPose; } }
        public ShotAsset ActiveShot { get { return m_ActiveShot; } }
        public Component OutputVcam { get { return m_OutputVcam; } }
        public Component GameVcam { get { return m_GameVcam; } }

        public void SetActiveShot(ShotAsset shot)
        {
            m_ActiveShot = shot;
        }

        void OnEnable()
        {
            RebuildOutputs();
            m_FocusSolver.Reset(m_FocusProfile != null ? 10f : 10f);
        }

        void OnDisable()
        {
            if (m_FocusOutput != null)
            {
                m_FocusOutput.Dispose();
                m_FocusOutput = NullFocusOutput.Instance;
            }
            m_Output = NullCameraOutput.Instance;
            m_HasPose = false;
            m_ActiveShot = null;
            m_HasLookLast = false;
            m_HasFollowLast = false;
        }

        public void RebuildOutputs()
        {
            m_Output = CineOutputFactory.GetCameraOutput(m_OutputVcam);
            m_Output.Bind(m_FallbackCamera != null ? m_FallbackCamera : Camera.main);
            if (m_FocusOutput != null && !ReferenceEquals(m_FocusOutput, NullFocusOutput.Instance))
                m_FocusOutput.Dispose();
            m_FocusOutput = CineOutputFactory.GetFocusOutput(transform, m_FocusProfile);
        }

        public TargetSample SampleLookAt(Transform target, Vector3 offset, float dt)
        {
            if (target == null)
                return default(TargetSample);
            return SampleTransform(target, offset, dt, ref m_LookLast, ref m_HasLookLast);
        }

        public TargetSample SampleFollow(Transform target, Vector3 offset, float dt)
        {
            if (target == null)
                return default(TargetSample);
            return SampleTransform(target, offset, dt, ref m_FollowLast, ref m_HasFollowLast);
        }

        static TargetSample SampleTransform(Transform target, Vector3 offset, float dt, ref Vector3 lastPos, ref bool hasLast)
        {
            Vector3 pos = target.TransformPoint(offset);
            Vector3 vel = Vector3.zero;
            if (hasLast && dt > 1e-3f)
            {
                vel = (pos - lastPos) / dt;
                float maxSpeed = 40f;
                float sqr = vel.sqrMagnitude;
                if (sqr > maxSpeed * maxSpeed)
                    vel *= maxSpeed / Mathf.Sqrt(sqr);
            }
            lastPos = pos;
            hasLast = true;
            return new TargetSample
            {
                Position = pos,
                Velocity = vel,
                Rotation = target.rotation,
                Valid = true
            };
        }

        public void SubmitPose(in CameraPose pose, float dt, float focusDistanceHint, FocusMode focusMode, Transform focusTarget)
        {
            CameraPose finalPose = pose;
            SolverMath.ClampOptics(ref finalPose);
            if (finalPose.Rotation == default(Quaternion))
                finalPose.Rotation = Quaternion.identity;

            TargetSample protect = default(TargetSample);
            if (focusTarget != null)
            {
                protect.Position = focusTarget.position;
                protect.Valid = true;
            }
            SolverMath.KeepMinDistance(ref finalPose, in protect, m_MinTargetDistance);

            m_LastPose = finalPose;
            m_HasPose = true;
            m_Output.Apply(in finalPose);

            int count = 0;
            if (focusMode == FocusMode.FixedDistance)
            {
                m_FocusBuffer[count++] = new FocusRequest
                {
                    Distance = focusDistanceHint,
                    Weight = 1f,
                    SourceId = 1
                };
            }
            else if (focusMode == FocusMode.Target && focusTarget != null)
            {
                m_FocusBuffer[count++] = new FocusRequest
                {
                    Distance = Mathf.Max(0.1f, Vector3.Distance(finalPose.Position, focusTarget.position)),
                    Weight = 1f,
                    SourceId = 2
                };
            }
            else if (focusMode == FocusMode.Hyperfocal)
            {
                m_FocusBuffer[count++] = new FocusRequest
                {
                    Distance = Mathf.Max(focusDistanceHint, 50f),
                    Weight = 1f,
                    SourceId = 3
                };
            }

            var state = m_FocusSolver.Evaluate(m_FocusBuffer, count, focusDistanceHint, dt, m_FocusProfile);
            finalPose.FocusDistance = state.Distance;
            m_LastPose = finalPose;
            m_FocusOutput.Apply(in state, m_FocusProfile);
        }

        public void ReleasePose(float dt)
        {
        }

        public void BlendToGameCamera(float k)
        {
            if (m_GameVcam == null || !m_HasPose)
                return;
            Transform gameTr = m_GameVcam.transform;
            CameraPose blended = m_LastPose;
            blended.Position = Vector3.Lerp(m_LastPose.Position, gameTr.position, k);
            blended.Rotation = Quaternion.Slerp(m_LastPose.Rotation, gameTr.rotation, k);
            m_Output.Apply(in blended);
            m_LastPose = blended;
        }

        public void SetControlling(bool controlling)
        {
            m_Output.SetControlling(controlling);
        }
    }
}
