using UnityEngine;

namespace CineShot.Core
{
    public struct CraneSolver : ISolver
    {
        public void Solve(in ShotContext ctx, in RigParams p, ref CameraPose pose)
        {
            SolveStatic(in ctx, in p, ref pose);
        }

        public static void SolveStatic(in ShotContext ctx, in RigParams p, ref CameraPose pose)
        {
            float u = SolverMath.NormalizedTime(in ctx);
            Vector3 origin = ctx.Follow.Valid ? ctx.Follow.Position : Vector3.zero;
            pose.Position = Point(in p, u, origin);
            SolverMath.ApplyComposition(ref pose, ctx.CompositionOffset);
            if (ctx.LookAt.Valid)
                SolverMath.LookAtTarget(in ctx, ref pose, 0f, 0f);
            else
            {
                Vector3 ahead = Point(in p, Mathf.Clamp01(u + 0.04f), origin);
                Vector3 aim = ahead - pose.Position;
                if (aim.sqrMagnitude < 1e-8f)
                    aim = p.B - p.A;
                if (aim.sqrMagnitude > 1e-8f)
                    pose.Rotation = Quaternion.LookRotation(aim.normalized, Vector3.up);
            }
        }

        public static Vector3 Bulge(in RigParams p)
        {
            return new Vector3(p.P0, p.P1, p.P2);
        }

        public static Vector3 Point(in RigParams p, float u, Vector3 origin)
        {
            float eased = u * u * (3f - 2f * u);
            eased = Mathf.Clamp01(eased);
            return origin + Vector3.Lerp(p.A, p.B, eased) + Bulge(in p) * Mathf.Sin(eased * Mathf.PI);
        }
    }

    public struct ShoulderSolver : ISolver
    {
        public void Solve(in ShotContext ctx, in RigParams p, ref CameraPose pose)
        {
            SolveStatic(in ctx, in p, ref pose);
        }

        public static void SolveStatic(in ShotContext ctx, in RigParams p, ref CameraPose pose)
        {
            Vector3 followPos = ctx.Follow.Valid ? ctx.Follow.Position : SolverMath.Anchor(in ctx);
            Quaternion followRot = ctx.Follow.Valid ? ctx.Follow.Rotation : Quaternion.identity;
            float side = p.I0 >= 0 ? 1f : -1f;
            Vector3 shoulder = followPos
                               + followRot * (Vector3.right * (side * p.P0))
                               + Vector3.up * p.P1
                               + followRot * (Vector3.back * 0.35f);
            pose.Position = shoulder;
            SolverMath.LookAtTarget(in ctx, ref pose, p.P2, 0f);
            pose.Dutch = p.P3;
            pose.NearClip = Mathf.Min(pose.NearClip, 0.05f);
            SolverMath.ApplyComposition(ref pose, ctx.CompositionOffset);
        }
    }

    public struct HandheldSolver : ISolver
    {
        public void Solve(in ShotContext ctx, in RigParams p, ref CameraPose pose)
        {
            SolveStatic(in ctx, in p, ref pose);
        }

        public static void SolveStatic(in ShotContext ctx, in RigParams p, ref CameraPose pose)
        {
            float t = ctx.LocalTime * Mathf.Max(0.01f, p.P1) + ctx.Seed * 0.137f;
            float nx = (Mathf.PerlinNoise(t, 0.31f) - 0.5f) * 2f;
            float ny = (Mathf.PerlinNoise(0.71f, t) - 0.5f) * 2f;
            float nz = (Mathf.PerlinNoise(t * 0.7f, 1.17f) - 0.5f) * 2f;
            pose.Position += pose.Rotation * new Vector3(nx, ny, nz * 0.35f) * p.P0;
            pose.Rotation *= Quaternion.Euler(ny * p.P2, nx * p.P2, nx * p.P3);
        }
    }

    public struct SplineDollySolver : ISolver
    {
        public void Solve(in ShotContext ctx, in RigParams p, ref CameraPose pose)
        {
            SolveStatic(in ctx, in p, ref pose);
        }

        public static void SolveStatic(in ShotContext ctx, in RigParams p, ref CameraPose pose)
        {
            float u = SolverMath.NormalizedTime(in ctx);
            if (ctx.Spline != null)
                pose.Position = ctx.Spline.Evaluate(u);
            else
                pose.Position = Vector3.Lerp(p.A, p.B, u) + Vector3.up * p.P3;

            if (ctx.LookAt.Valid)
            {
                TargetSample look = ctx.LookAt;
                if (p.P2 > 0f)
                    look.Position = SolverMath.Predict(in look, p.P2);
                var lookCtx = ctx;
                lookCtx.LookAt = look;
                SolverMath.LookAtTarget(in lookCtx, ref pose, 0f, 0f);
            }
            else
            {
                float aheadU = Mathf.Clamp01(u + 0.02f);
                Vector3 ahead = ctx.Spline != null
                    ? ctx.Spline.Evaluate(aheadU)
                    : Vector3.Lerp(p.A, p.B, aheadU) + Vector3.up * p.P3;
                Vector3 aim = ahead - pose.Position;
                if (aim.sqrMagnitude > 1e-8f)
                    pose.Rotation = Quaternion.LookRotation(aim.normalized, Vector3.up);
            }
            SolverMath.ApplyComposition(ref pose, ctx.CompositionOffset);
        }
    }
}
