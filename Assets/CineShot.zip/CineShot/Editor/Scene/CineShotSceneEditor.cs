using System;
using System.Linq.Expressions;
using System.Reflection;
using CineShot.Core;
using CineShot.Output;
using UnityEditor;
using UnityEditor.Timeline;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.Timeline;

namespace CineShot.Editor
{
    [InitializeOnLoad]
    static class CineShotSceneEditor
    {
        internal const string k_FollowKey = "CineShot.FollowPlayhead";
        internal const string k_OverrideKey = "CineShot.WriteClip";

        static CineShotRig s_Rig;
        static bool s_Held;
        static bool s_GoWasActive;
        static double s_LastDirectorTime = double.NaN;
        static object s_HookedTimelineState;

        static CineShotSceneEditor()
        {
            EditorApplication.update += OnEditorUpdate;
            SceneView.duringSceneGui += OnSceneGui;
            EditorApplication.playModeStateChanged += OnPlayMode;
            AssemblyReloadEvents.beforeAssemblyReload += Release;
            Undo.undoRedoPerformed += OnUndo;
        }

        static void OnPlayMode(PlayModeStateChange state)
        {
            if (state == PlayModeStateChange.ExitingEditMode)
                Release();
        }

        static void OnUndo()
        {
            SceneView.RepaintAll();
        }

        static void OnEditorUpdate()
        {
            if (Application.isPlaying)
            {
                Release();
                return;
            }

            TryHookTimelineButton();
            var ctx = BuildContext();
            if (ctx == null)
            {
                Release();
                return;
            }

            ApplyPreview(ctx);
            if (!Mathf.Approximately((float)s_LastDirectorTime, (float)ctx.DirectorTime))
            {
                s_LastDirectorTime = ctx.DirectorTime;
                SceneView.RepaintAll();
            }
        }

        static void OnSceneGui(SceneView view)
        {
            if (Application.isPlaying)
                return;

            var ctx = BuildContext();
            if (ctx == null)
                return;

            DrawFrustumsAndTargets(ctx);
            if (ctx.Selected)
                DrawGizmos(ctx);
            ApplyPreview(ctx);

            if (ctx.Selected && GUI.changed)
                view.Repaint();
        }

        internal sealed class PreviewContext
        {
            public PlayableDirector Director;
            public TimelineClip TimelineClip;
            public CineShotClip Clip;
            public ShotAsset Shot;
            public CineShotRig Rig;
            public Transform Look;
            public Transform Follow;
            public float LocalTime;
            public float Duration;
            public bool InsidePlayhead;
            public bool Selected;
            public bool WriteOverride;
            public double DirectorTime;
            public RigParams Params;
            public CameraPose Pose;
            public float AuthoredFov;
            public Vector3 LookOffset;
            public Vector3 FollowOffset;
            public TargetSample LookSample;
            public TargetSample FollowSample;
            public Vector3 Anchor;
            public Quaternion AnchorRot;
        }

        static double ReadPlayhead(PlayableDirector director)
        {
            var prop = typeof(TimelineEditor).GetProperty("inspectedSequenceTime", BindingFlags.NonPublic | BindingFlags.Static);
            if (prop != null)
            {
                object value = prop.GetValue(null, null);
                if (value is double)
                    return (double)value;
            }
            return director != null ? director.time : 0d;
        }

        internal static PreviewContext BuildContext()
        {
            TimelineClip selectedTimeline = TimelineEditor.selectedClip;
            CineShotClip selectedClip = selectedTimeline != null ? selectedTimeline.asset as CineShotClip : null;
            bool selectedValid = selectedClip != null && selectedClip.shot != null && selectedTimeline != null;

            PlayableDirector director = null;
            if (selectedValid)
                director = FindDirector(selectedTimeline.GetParentTrack() != null ? selectedTimeline.GetParentTrack().timelineAsset : null);
            if (director == null)
                director = TimelineEditor.inspectedDirector;
            if (director == null || director.playableAsset == null)
                return null;

            double playhead = ReadPlayhead(director);
            bool follow = SessionState.GetBool(k_FollowKey, true);
            TimelineClip timelineClip;
            CineShotClip selected;
            if (follow)
            {
                timelineClip = FindClipAtTime(director, playhead);
                selected = timelineClip != null ? timelineClip.asset as CineShotClip : null;
                if (selected == null || selected.shot == null)
                    return null;
            }
            else if (selectedValid)
            {
                timelineClip = selectedTimeline;
                selected = selectedClip;
            }
            else
            {
                timelineClip = FindClipAtTime(director, playhead);
                selected = timelineClip != null ? timelineClip.asset as CineShotClip : null;
                if (selected == null || selected.shot == null)
                    return null;
            }

            var ctx = new PreviewContext();
            ctx.Director = director;
            ctx.TimelineClip = timelineClip;
            ctx.Clip = selected;
            ctx.Shot = selected.shot;
            ctx.Selected = TimelineEditor.selectedClip != null && TimelineEditor.selectedClip.asset == selected;
            ctx.DirectorTime = playhead;
            ctx.Duration = Mathf.Max(0.05f, (float)timelineClip.duration);
            ctx.InsidePlayhead = playhead >= timelineClip.start && playhead < timelineClip.end;
            ctx.WriteOverride = SessionState.GetBool(k_OverrideKey, true);

            if (follow && ctx.InsidePlayhead)
                ctx.LocalTime = Mathf.Clamp((float)timelineClip.ToLocalTimeUnbound(playhead), 0f, ctx.Duration);
            else if (follow)
                ctx.LocalTime = 0f;
            else
                ctx.LocalTime = Mathf.Clamp(SessionState.GetFloat("CineShot.ManualTime", 0f), 0f, ctx.Duration);

            ctx.Look = selected.lookAt.Resolve(director);
            ctx.Follow = selected.follow.Resolve(director);
            ctx.Rig = ResolveRig(director, timelineClip);

            RigParams rigParams;
            Vector3 composition;
            float fov, near, far, focusDistance;
            FocusMode mode;
            EasingAsset ignoredIn, ignoredOut;
            selected.overrides.ApplyTo(ctx.Shot, out rigParams, out composition, out fov, out near, out far,
                out mode, out focusDistance, out ignoredIn, out ignoredOut);
            ctx.Params = rigParams;
            ctx.AuthoredFov = fov;
            ctx.LookOffset = selected.overrides.ResolveLookOffset(ctx.Shot);
            ctx.FollowOffset = selected.overrides.ResolveFollowOffset(ctx.Shot);

            if (ctx.Rig != null)
            {
                ctx.LookSample = ctx.Rig.SampleLookAt(ctx.Look, ctx.LookOffset, 0f);
                ctx.FollowSample = ctx.Rig.SampleFollow(ctx.Follow, ctx.FollowOffset, 0f);
            }
            else
            {
                ctx.LookSample = SampleRaw(ctx.Look, ctx.LookOffset);
                ctx.FollowSample = SampleRaw(ctx.Follow, ctx.FollowOffset);
            }

            ctx.Anchor = ctx.FollowSample.Valid ? ctx.FollowSample.Position
                : (ctx.LookSample.Valid ? ctx.LookSample.Position : Vector3.zero);
            ctx.AnchorRot = ctx.FollowSample.Valid ? ctx.FollowSample.Rotation : Quaternion.identity;

            var solve = new ShotContext
            {
                LocalTime = ctx.LocalTime,
                Duration = ctx.Duration,
                DeltaTime = 0f,
                LookAt = ctx.LookSample,
                Follow = ctx.FollowSample,
                CompositionOffset = composition,
                Seed = ctx.Shot.Seed,
                Spline = selected.spline
            };
            var pose = CameraPose.Identity;
            pose.Fov = fov;
            pose.NearClip = near;
            pose.FarClip = far;
            pose.FocusDistance = focusDistance;
            SolverDispatch.Solve(ctx.Shot.rigKind, in solve, in rigParams, ref pose);
            if (ctx.Shot.handheld.enabled)
            {
                var handheld = ctx.Shot.handheld.parameters;
                HandheldSolver.SolveStatic(in solve, in handheld, ref pose);
            }
            ctx.Pose = BlendAtPlayhead(ctx, pose);
            return ctx;
        }

        static CameraPose BlendAtPlayhead(PreviewContext ctx, CameraPose current)
        {
            if (ctx.Clip == null || ctx.Clip.blendMode == ShotBlendMode.Cut || ctx.Director == null || ctx.TimelineClip == null)
                return current;
            const float window = 0.5f;
            TimelineClip prev = FindPreviousClip(ctx.Director, ctx.TimelineClip);
            if (prev == null)
                return current;
            bool overlapping = ctx.DirectorTime < prev.end && ctx.DirectorTime >= ctx.TimelineClip.start;
            double into = ctx.DirectorTime - ctx.TimelineClip.start;
            if (!overlapping && (into < 0d || into > window))
                return current;
            float prevLocal = overlapping
                ? Mathf.Clamp((float)prev.ToLocalTimeUnbound(ctx.DirectorTime), 0f, (float)prev.duration)
                : Mathf.Max(0f, (float)prev.duration - 0.02f);
            CameraPose prevPose;
            if (!TrySolveClip(ctx.Director, prev, prevLocal, ctx.Rig, out prevPose))
                return current;
            float u;
            if (overlapping)
            {
                double overlap = System.Math.Max(0.05d, prev.end - ctx.TimelineClip.start);
                u = Mathf.Clamp01((float)(into / overlap));
            }
            else
                u = Mathf.Clamp01((float)(into / window));
            u = u * u * (3f - 2f * u);
            return CameraPose.Lerp(prevPose, current, u);
        }

        static TimelineClip FindPreviousClip(PlayableDirector director, TimelineClip current)
        {
            var timeline = director.playableAsset as TimelineAsset;
            if (timeline == null || current == null)
                return null;
            TimelineClip best = null;
            foreach (var track in timeline.GetOutputTracks())
            {
                if (!(track is CineShotTrack))
                    continue;
                foreach (var clip in track.GetClips())
                {
                    if (!(clip.asset is CineShotClip) || clip == current)
                        continue;
                    if (clip.start >= current.start)
                        continue;
                    if (best == null || clip.start > best.start)
                        best = clip;
                }
            }
            return best;
        }

        static bool TrySolveClip(PlayableDirector director, TimelineClip timelineClip, float localTime, CineShotRig rig, out CameraPose pose)
        {
            pose = CameraPose.Identity;
            var cine = timelineClip != null ? timelineClip.asset as CineShotClip : null;
            if (cine == null || cine.shot == null)
                return false;
            float duration = Mathf.Max(0.05f, (float)timelineClip.duration);
            localTime = Mathf.Clamp(localTime, 0f, duration);
            RigParams rigParams;
            Vector3 composition;
            float fov, near, far, focusDistance;
            FocusMode mode;
            EasingAsset ignoredIn, ignoredOut;
            cine.overrides.ApplyTo(cine.shot, out rigParams, out composition, out fov, out near, out far,
                out mode, out focusDistance, out ignoredIn, out ignoredOut);
            Vector3 lookOffset = cine.overrides.ResolveLookOffset(cine.shot);
            Vector3 followOffset = cine.overrides.ResolveFollowOffset(cine.shot);
            Transform look = cine.lookAt.Resolve(director);
            Transform follow = cine.follow.Resolve(director);
            TargetSample lookSample = rig != null ? rig.SampleLookAt(look, lookOffset, 0f) : SampleRaw(look, lookOffset);
            TargetSample followSample = rig != null ? rig.SampleFollow(follow, followOffset, 0f) : SampleRaw(follow, followOffset);
            var solve = new ShotContext
            {
                LocalTime = localTime,
                Duration = duration,
                LookAt = lookSample,
                Follow = followSample,
                CompositionOffset = composition,
                Seed = cine.shot.Seed,
                Spline = cine.spline
            };
            pose.Fov = fov;
            pose.NearClip = near;
            pose.FarClip = far;
            pose.FocusDistance = focusDistance;
            SolverDispatch.Solve(cine.shot.rigKind, in solve, in rigParams, ref pose);
            return true;
        }

        static TargetSample SampleRaw(Transform target, Vector3 offset)
        {
            if (target == null)
                return default(TargetSample);
            return new TargetSample
            {
                Position = target.TransformPoint(offset),
                Rotation = target.rotation,
                Valid = true
            };
        }

        static PlayableDirector FindDirector(TimelineAsset asset)
        {
            var inspected = TimelineEditor.inspectedDirector;
            if (asset == null)
                return inspected;
            if (inspected != null && inspected.playableAsset == asset)
                return inspected;
#if UNITY_2023_1_OR_NEWER
            var all = UnityEngine.Object.FindObjectsByType<PlayableDirector>(FindObjectsSortMode.None);
#else
            var all = UnityEngine.Object.FindObjectsOfType<PlayableDirector>();
#endif
            for (int i = 0; i < all.Length; i++)
            {
                if (all[i] != null && all[i].playableAsset == asset)
                    return all[i];
            }
            return inspected;
        }

        static TimelineClip FindClipAtTime(PlayableDirector director, double time)
        {
            var timeline = director.playableAsset as TimelineAsset;
            if (timeline == null)
                return null;
            TimelineClip best = null;
            foreach (var track in timeline.GetOutputTracks())
            {
                if (!(track is CineShotTrack))
                    continue;
                foreach (var clip in track.GetClips())
                {
                    if (clip.asset is CineShotClip && time >= clip.start && time < clip.end)
                    {
                        if (best == null || clip.start >= best.start)
                            best = clip;
                    }
                }
            }
            return best;
        }

        static CineShotRig ResolveRig(PlayableDirector director, TimelineClip clip)
        {
            var track = clip != null ? clip.GetParentTrack() as CineShotTrack : null;
            if (track != null && director != null)
            {
                var bound = director.GetGenericBinding(track) as CineShotRig;
                if (bound != null)
                    return bound;
            }
#if UNITY_2023_1_OR_NEWER
            return UnityEngine.Object.FindFirstObjectByType<CineShotRig>();
#else
            return UnityEngine.Object.FindObjectOfType<CineShotRig>();
#endif
        }

        static void ApplyPreview(PreviewContext ctx)
        {
            if (ctx.Rig == null || ctx.Rig.OutputVcam == null)
                return;
            Acquire(ctx.Rig);
            Transform focus = ctx.Look != null ? ctx.Look : ctx.Follow;
            ctx.Rig.SubmitPose(in ctx.Pose, 0f, ctx.Pose.FocusDistance, ctx.Shot.focusMode, focus);
            ctx.Rig.SetControlling(true);
            PushGameCamera(ctx.Rig.LastPose);
            EditorApplication.QueuePlayerLoopUpdate();
            RepaintGameViews();
        }

        static void PushGameCamera(CameraPose pose)
        {
            var cam = Camera.main;
            if (cam == null)
                return;
            Quaternion rot = pose.Rotation * Quaternion.AngleAxis(pose.Dutch, Vector3.forward);
            cam.transform.SetPositionAndRotation(pose.Position, rot);
            cam.fieldOfView = Mathf.Clamp(pose.Fov, 1f, 179f);
            cam.nearClipPlane = Mathf.Max(0.01f, pose.NearClip);
            cam.farClipPlane = Mathf.Max(cam.nearClipPlane + 0.01f, pose.FarClip);
        }

        static void RepaintGameViews()
        {
            var gameViewType = typeof(UnityEditor.Editor).Assembly.GetType("UnityEditor.GameView");
            if (gameViewType == null)
                return;
            var views = Resources.FindObjectsOfTypeAll(gameViewType);
            for (int i = 0; i < views.Length; i++)
            {
                var window = views[i] as EditorWindow;
                if (window != null)
                    window.Repaint();
            }
        }

        static void Acquire(CineShotRig rig)
        {
            if (s_Held && s_Rig == rig)
                return;
            Release();
            var go = rig.OutputVcam.gameObject;
            s_GoWasActive = go.activeSelf;
            if (!go.activeSelf)
                go.SetActive(true);
            OutputBootstrap.Register();
            rig.RebuildOutputs();
            s_Rig = rig;
            s_Held = true;
        }

        static void Release()
        {
            if (!s_Held)
                return;
            if (s_Rig != null)
            {
                s_Rig.SetControlling(false);
                if (s_Rig.OutputVcam != null && !s_GoWasActive)
                    s_Rig.OutputVcam.gameObject.SetActive(false);
            }
            s_Held = false;
            s_Rig = null;
        }

        static void DrawFrustumsAndTargets(PreviewContext ctx)
        {
            var pose = ctx.Pose;
            Handles.color = new Color(0.35f, 0.75f, 1f, 0.95f);
            DrawFrustum(pose.Position, pose.Rotation, pose.Fov, pose.NearClip, Mathf.Min(pose.FarClip, 8f));
            Handles.Label(pose.Position, " 镜头 " + ctx.Shot.displayName);

            if (ctx.LookSample.Valid)
            {
                Handles.color = new Color(1f, 0.85f, 0.2f, 0.9f);
                Handles.DrawDottedLine(pose.Position, ctx.LookSample.Position, 4f);
                Handles.SphereHandleCap(0, ctx.LookSample.Position, Quaternion.identity, HandleUtility.GetHandleSize(ctx.LookSample.Position) * 0.08f, EventType.Repaint);
                Handles.Label(ctx.LookSample.Position, " 注视");
            }
            if (ctx.FollowSample.Valid)
            {
                Handles.color = new Color(0.4f, 1f, 0.55f, 0.9f);
                Handles.DrawWireDisc(ctx.Anchor, Vector3.up, HandleUtility.GetHandleSize(ctx.Anchor) * 0.15f);
                Handles.Label(ctx.Anchor, " 跟随");
            }
        }

        static void DrawFrustum(Vector3 pos, Quaternion rot, float fov, float near, float far)
        {
            float aspect = 16f / 9f;
            Vector3[] n = FrustumCorners(pos, rot, fov, aspect, Mathf.Max(0.05f, near));
            Vector3[] f = FrustumCorners(pos, rot, fov, aspect, Mathf.Max(near + 0.2f, far));
            for (int i = 0; i < 4; i++)
            {
                Handles.DrawLine(n[i], n[(i + 1) % 4]);
                Handles.DrawLine(f[i], f[(i + 1) % 4]);
                Handles.DrawLine(n[i], f[i]);
            }
            Handles.DrawLine(pos, n[0]);
        }

        static Vector3[] FrustumCorners(Vector3 pos, Quaternion rot, float fov, float aspect, float dist)
        {
            float halfY = Mathf.Tan(fov * 0.5f * Mathf.Deg2Rad) * dist;
            float halfX = halfY * aspect;
            Vector3 right = rot * Vector3.right;
            Vector3 up = rot * Vector3.up;
            Vector3 fwd = rot * Vector3.forward;
            Vector3 c = pos + fwd * dist;
            return new[]
            {
                c - right * halfX + up * halfY,
                c + right * halfX + up * halfY,
                c + right * halfX - up * halfY,
                c - right * halfX - up * halfY
            };
        }

        static void DrawGizmos(PreviewContext ctx)
        {
            var p = ctx.Params;
            switch (ctx.Shot.rigKind)
            {
                case RigKind.Static:
                    DrawStatic(ctx, p);
                    break;
                case RigKind.DollyTrack:
                    DrawDolly(ctx, p);
                    break;
                case RigKind.Orbit:
                    DrawOrbit(ctx, p);
                    break;
                case RigKind.PushPull:
                    DrawPush(ctx, p);
                    break;
                case RigKind.Crane:
                    DrawCrane(ctx, p);
                    break;
                case RigKind.Shoulder:
                    DrawShoulder(ctx, p);
                    break;
                case RigKind.SplineDolly:
                    DrawSpline(ctx);
                    break;
                case RigKind.Handheld:
                    DrawHandheld(ctx, p);
                    break;
            }

            if (ctx.Look != null)
            {
                Vector3 world = ctx.Look.TransformPoint(ctx.LookOffset);
                float size = HandleUtility.GetHandleSize(world) * 0.12f;
                Handles.color = new Color(1f, 0.75f, 0.15f, 1f);
                EditorGUI.BeginChangeCheck();
                var fmh_401_63_639300729143862597 = Quaternion.identity; Vector3 moved = Handles.FreeMoveHandle(world, size, Vector3.one * 0.05f, Handles.SphereHandleCap);
                if (EditorGUI.EndChangeCheck())
                    WriteLookOffset(ctx, ctx.Look.InverseTransformPoint(moved));
            }
        }

        static void DrawStatic(PreviewContext ctx, RigParams p)
        {
            Vector3 world = ctx.Anchor + ctx.AnchorRot * p.A;
            EditorGUI.BeginChangeCheck();
            Vector3 moved = Handles.PositionHandle(world, ctx.AnchorRot);
            if (EditorGUI.EndChangeCheck())
            {
                p.A = Quaternion.Inverse(ctx.AnchorRot) * (moved - ctx.Anchor);
                WriteRig(ctx, p, "调整静态偏移");
            }
            Handles.color = new Color(0.4f, 0.8f, 1f, 0.8f);
            Handles.DrawDottedLine(ctx.Anchor, world, 4f);
            Handles.Label(world, " 机位偏移");
        }

        static void DrawDolly(PreviewContext ctx, RigParams p)
        {
            EditorGUI.BeginChangeCheck();
            Vector3 a = Handles.PositionHandle(p.A, Quaternion.identity);
            if (EditorGUI.EndChangeCheck())
            {
                p.A = a;
                WriteRig(ctx, p, "调整轨道起点");
            }
            EditorGUI.BeginChangeCheck();
            Vector3 b = Handles.PositionHandle(p.B, Quaternion.identity);
            if (EditorGUI.EndChangeCheck())
            {
                p.B = b;
                WriteRig(ctx, p, "调整轨道终点");
            }
            Handles.color = new Color(0.4f, 0.85f, 1f, 0.45f);
            Handles.DrawLine(p.A, p.B);
            Handles.color = Color.cyan;
            Vector3 prev = DollyTrackSolver.PointOnTrack(in p, 0f);
            for (int s = 1; s <= 16; s++)
            {
                Vector3 point = DollyTrackSolver.PointOnTrack(in p, s / 16f);
                Handles.DrawLine(prev, point);
                prev = point;
            }
            float u = ctx.Duration > 1e-4f ? Mathf.Clamp01(ctx.LocalTime / ctx.Duration) : 0f;
            float eased = u * u * (3f - 2f * u);
            Vector3 along, side, up;
            DollyTrackSolver.TrackFrame(p.A, p.B, out along, out side, out up);
            Vector3 onTrack = Vector3.Lerp(p.A, p.B, eased);
            Vector3 cam = onTrack + side * p.P1 + up * p.P2;
            Handles.DrawDottedLine(onTrack, cam, 3f);
            EditorGUI.BeginChangeCheck();
            Vector3 moved = Handles.PositionHandle(cam, Quaternion.LookRotation(along, up));
            if (EditorGUI.EndChangeCheck())
            {
                Vector3 delta = moved - onTrack;
                p.P1 = Vector3.Dot(delta, side);
                p.P2 = Vector3.Dot(delta, up);
                WriteRig(ctx, p, "调整相对轨道偏移");
            }
            Handles.Label(p.A, " 轨道起点");
            Handles.Label(p.B, " 轨道终点");
            Handles.Label(cam, " 相对轨道偏移");
        }

        static void DrawOrbit(PreviewContext ctx, RigParams p)
        {
            bool follow = ctx.FollowSample.Valid;
            Vector3 center = follow ? ctx.FollowSample.Position : p.B;
            float ang = (p.P0 + p.P1 * ctx.LocalTime) * Mathf.Deg2Rad;
            Vector3 dir = new Vector3(Mathf.Sin(ang), 0f, Mathf.Cos(ang));
            float radius = Mathf.Max(0.2f, Mathf.Abs(p.P2));
            Vector3 handle = center + dir * radius + Vector3.up * p.P3;
            Handles.color = new Color(0.5f, 0.85f, 1f, 0.7f);
            Handles.DrawWireDisc(center + Vector3.up * p.P3, Vector3.up, radius);
            if (!follow)
            {
                EditorGUI.BeginChangeCheck();
                Vector3 movedCenter = Handles.PositionHandle(p.B, Quaternion.identity);
                if (EditorGUI.EndChangeCheck())
                {
                    p.B = movedCenter;
                    WriteRig(ctx, p, "调整环绕圆心");
                }
                Handles.Label(p.B, " 圆心");
            }
            EditorGUI.BeginChangeCheck();
            Vector3 moved = Handles.PositionHandle(handle, Quaternion.identity);
            if (EditorGUI.EndChangeCheck())
            {
                Vector3 flat = moved - center;
                p.P3 = flat.y;
                flat.y = 0f;
                p.P2 = Mathf.Max(0.2f, flat.magnitude);
                float newAng = Mathf.Atan2(flat.x, flat.z) * Mathf.Rad2Deg;
                p.P0 = newAng - p.P1 * ctx.LocalTime;
                WriteRig(ctx, p, "调整环绕");
            }
            Handles.Label(handle, " 环绕机位");
        }

        static void DrawPush(PreviewContext ctx, RigParams p)
        {
            Vector3 back = ctx.FollowSample.Valid ? -(ctx.AnchorRot * Vector3.forward) : Vector3.back;
            if (back.sqrMagnitude < 1e-6f)
                back = Vector3.back;
            back.Normalize();
            Vector3 start = ctx.Anchor + back * p.P0 + Vector3.up * p.P2;
            Vector3 end = ctx.Anchor + back * p.P1 + Vector3.up * p.P2;
            Handles.color = Color.white;
            Handles.DrawLine(start, end);
            EditorGUI.BeginChangeCheck();
            Vector3 ms = Handles.PositionHandle(start, Quaternion.LookRotation(back));
            if (EditorGUI.EndChangeCheck())
            {
                p.P0 = Mathf.Max(0.2f, Vector3.Dot(ms - ctx.Anchor, back));
                p.P2 = ms.y - ctx.Anchor.y;
                WriteRig(ctx, p, "调整推拉起点");
            }
            EditorGUI.BeginChangeCheck();
            Vector3 me = Handles.PositionHandle(end, Quaternion.LookRotation(back));
            if (EditorGUI.EndChangeCheck())
            {
                p.P1 = Mathf.Max(0.2f, Vector3.Dot(me - ctx.Anchor, back));
                WriteRig(ctx, p, "调整推拉终点");
            }
            Handles.Label(start, " 起始距离");
            Handles.Label(end, " 结束距离");
        }

        static void DrawCrane(PreviewContext ctx, RigParams p)
        {
            Vector3 origin = ctx.FollowSample.Valid ? ctx.FollowSample.Position : Vector3.zero;
            Handles.color = Color.cyan;
            Vector3 prev = CraneSolver.Point(in p, 0f, origin);
            for (int s = 1; s <= 24; s++)
            {
                Vector3 point = CraneSolver.Point(in p, s / 24f, origin);
                Handles.DrawLine(prev, point);
                prev = point;
            }
            Vector3 start = CraneSolver.Point(in p, 0f, origin);
            Vector3 end = CraneSolver.Point(in p, 1f, origin);
            Vector3 mid = CraneSolver.Point(in p, 0.5f, origin);
            EditorGUI.BeginChangeCheck();
            Vector3 ms = Handles.PositionHandle(start, Quaternion.identity);
            if (EditorGUI.EndChangeCheck())
            {
                p.A = ms - origin;
                WriteRig(ctx, p, "调整摇臂起点");
            }
            EditorGUI.BeginChangeCheck();
            Vector3 me = Handles.PositionHandle(end, Quaternion.identity);
            if (EditorGUI.EndChangeCheck())
            {
                p.B = me - origin;
                WriteRig(ctx, p, "调整摇臂终点");
            }
            EditorGUI.BeginChangeCheck();
            Vector3 mm = Handles.PositionHandle(mid, Quaternion.identity);
            if (EditorGUI.EndChangeCheck())
            {
                Vector3 bulge = (mm - origin) - Vector3.Lerp(p.A, p.B, 0.5f);
                p.P0 = bulge.x;
                p.P1 = bulge.y;
                p.P2 = bulge.z;
                WriteRig(ctx, p, "调整摇臂弧线");
            }
            Handles.Label(start, " 起点");
            Handles.Label(end, " 终点");
            Handles.Label(mid, " 弧线");
            if (ctx.LookSample.Valid)
            {
                Handles.color = new Color(1f, 0.75f, 0.15f, 0.8f);
                Handles.DrawDottedLine(ctx.Pose.Position, ctx.LookSample.Position, 3f);
            }
        }

        static void DrawShoulder(PreviewContext ctx, RigParams p)
        {
            float side = p.I0 >= 0 ? 1f : -1f;
            Vector3 shoulder = ctx.Anchor
                               + ctx.AnchorRot * (Vector3.right * (side * p.P0))
                               + Vector3.up * p.P1
                               + ctx.AnchorRot * (Vector3.back * 0.35f);
            EditorGUI.BeginChangeCheck();
            Vector3 moved = Handles.PositionHandle(shoulder, ctx.AnchorRot);
            if (EditorGUI.EndChangeCheck())
            {
                p.P1 = moved.y - ctx.Anchor.y;
                Vector3 horizontal = moved - ctx.Anchor - Vector3.up * p.P1;
                horizontal -= ctx.AnchorRot * (Vector3.back * 0.35f);
                Vector3 local = Quaternion.Inverse(ctx.AnchorRot) * horizontal;
                p.P0 = Mathf.Abs(local.x);
                p.I0 = local.x >= 0f ? 1 : -1;
                WriteRig(ctx, p, "调整过肩机位");
            }
            Handles.Label(shoulder, p.I0 >= 0 ? " 右肩" : " 左肩");
        }

        static void DrawHandheld(PreviewContext ctx, RigParams p)
        {
            Vector3 axis = ctx.Pose.Rotation * Vector3.right;
            float size = HandleUtility.GetHandleSize(ctx.Pose.Position);
            Handles.color = new Color(1f, 0.45f, 0.3f, 1f);
            EditorGUI.BeginChangeCheck();
            Vector3 moved = Handles.Slider(ctx.Pose.Position + axis * p.P0, axis, size * 0.8f, Handles.SphereHandleCap, 0f);
            if (EditorGUI.EndChangeCheck())
            {
                p.P0 = Mathf.Max(0f, Vector3.Dot(moved - ctx.Pose.Position, axis));
                WriteRig(ctx, p, "调整手持振幅");
            }
        }

        static void DrawSpline(PreviewContext ctx)
        {
            var spline = ctx.Clip.spline;
            if (spline == null || spline.knots == null)
            {
                Handles.Label(ctx.Pose.Position, " 未指定样条");
                return;
            }
            Handles.color = new Color(1f, 0.55f, 0.2f, 0.9f);
            Vector3 prev = spline.Evaluate(0f);
            for (int s = 1; s <= 24; s++)
            {
                Vector3 point = spline.Evaluate(s / 24f);
                Handles.DrawLine(prev, point);
                prev = point;
            }
            for (int i = 0; i < spline.knots.Length; i++)
            {
                EditorGUI.BeginChangeCheck();
                Vector3 moved = Handles.PositionHandle(spline.knots[i], Quaternion.identity);
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(spline, "调整样条控制点");
                    spline.knots[i] = moved;
                    EditorUtility.SetDirty(spline);
                }
                Handles.Label(spline.knots[i], " 点" + (i + 1));
            }
        }

        internal static void SaveClipToTemplate(PreviewContext ctx)
        {
            if (ctx == null || ctx.Clip == null || ctx.Shot == null)
                return;
            Undo.RecordObject(ctx.Shot, "保存至模板");
            var over = ctx.Clip.overrides;
            ctx.Shot.rigParams = ctx.Params;
            ctx.Shot.fov = ctx.AuthoredFov;
            if ((over.mask & ShotOverrideMask.Optics) != 0)
            {
                ctx.Shot.nearClip = over.nearClip;
                ctx.Shot.farClip = over.farClip;
            }
            if ((over.mask & ShotOverrideMask.Composition) != 0)
                ctx.Shot.compositionOffset = over.compositionOffset;
            if ((over.mask & ShotOverrideMask.Focus) != 0)
            {
                ctx.Shot.focusMode = over.focusMode;
                ctx.Shot.focusDistance = over.focusDistance;
            }
            if ((over.mask & ShotOverrideMask.Easing) != 0)
            {
                if (over.easeIn != null)
                    ctx.Shot.easeIn = over.easeIn;
                if (over.easeOut != null)
                    ctx.Shot.easeOut = over.easeOut;
            }
            if ((over.mask & ShotOverrideMask.PriorityTags) != 0)
            {
                ctx.Shot.priority = over.priority;
                ctx.Shot.tags = over.tags;
            }
            if ((over.mask & ShotOverrideMask.TargetOffset) != 0)
            {
                var binding = ctx.Shot.targetBinding;
                binding.lookAtOffset = over.lookAtOffset;
                binding.followOffset = over.followOffset;
                ctx.Shot.targetBinding = binding;
            }
            EditorUtility.SetDirty(ctx.Shot);
            SceneView.RepaintAll();
        }

        internal static void WriteRig(PreviewContext ctx, RigParams p, string undoName)
        {
            if (ctx.WriteOverride)
            {
                Undo.RecordObject(ctx.Clip, undoName);
                var over = ctx.Clip.overrides;
                over.mask |= ShotOverrideMask.RigParams;
                over.rigParams = p;
                ctx.Clip.overrides = over;
                EditorUtility.SetDirty(ctx.Clip);
            }
            else if (ctx.Shot != null)
            {
                Undo.RecordObject(ctx.Shot, undoName);
                ctx.Shot.rigParams = p;
                EditorUtility.SetDirty(ctx.Shot);
                if (ctx.Clip != null && (ctx.Clip.overrides.mask & ShotOverrideMask.RigParams) != 0)
                {
                    Undo.RecordObject(ctx.Clip, undoName);
                    var over = ctx.Clip.overrides;
                    over.mask &= ~ShotOverrideMask.RigParams;
                    ctx.Clip.overrides = over;
                    EditorUtility.SetDirty(ctx.Clip);
                }
            }
            SceneView.RepaintAll();
        }

        internal static void WriteLookOffset(PreviewContext ctx, Vector3 lookOffset)
        {
            if (ctx.Clip == null)
                return;
            if (ctx.WriteOverride)
            {
                Undo.RecordObject(ctx.Clip, "调整注视偏移");
                var over = ctx.Clip.overrides;
                bool had = (over.mask & ShotOverrideMask.TargetOffset) != 0;
                over.mask |= ShotOverrideMask.TargetOffset;
                if (!had && ctx.Shot != null)
                    over.followOffset = ctx.Shot.targetBinding.followOffset;
                over.lookAtOffset = lookOffset;
                ctx.Clip.overrides = over;
                EditorUtility.SetDirty(ctx.Clip);
            }
            else if (ctx.Shot != null)
            {
                Undo.RecordObject(ctx.Shot, "调整注视偏移");
                var binding = ctx.Shot.targetBinding;
                binding.lookAtOffset = lookOffset;
                ctx.Shot.targetBinding = binding;
                EditorUtility.SetDirty(ctx.Shot);
                if ((ctx.Clip.overrides.mask & ShotOverrideMask.TargetOffset) != 0)
                {
                    Undo.RecordObject(ctx.Clip, "调整注视偏移");
                    var over = ctx.Clip.overrides;
                    over.mask &= ~ShotOverrideMask.TargetOffset;
                    ctx.Clip.overrides = over;
                    EditorUtility.SetDirty(ctx.Clip);
                }
            }
            SceneView.RepaintAll();
        }

        internal static void WriteFov(PreviewContext ctx, float fov)
        {
            if (ctx.Clip == null || ctx.Shot == null)
                return;
            if (ctx.WriteOverride)
            {
                Undo.RecordObject(ctx.Clip, "调整视场角");
                var over = ctx.Clip.overrides;
                bool had = (over.mask & ShotOverrideMask.Optics) != 0;
                over.mask |= ShotOverrideMask.Optics;
                over.fov = fov;
                if (!had)
                {
                    over.nearClip = ctx.Shot.nearClip;
                    over.farClip = ctx.Shot.farClip;
                }
                ctx.Clip.overrides = over;
                EditorUtility.SetDirty(ctx.Clip);
            }
            else
            {
                Undo.RecordObject(ctx.Shot, "调整视场角");
                ctx.Shot.fov = fov;
                EditorUtility.SetDirty(ctx.Shot);
                if ((ctx.Clip.overrides.mask & ShotOverrideMask.Optics) != 0)
                {
                    Undo.RecordObject(ctx.Clip, "调整视场角");
                    var over = ctx.Clip.overrides;
                    over.mask &= ~ShotOverrideMask.Optics;
                    ctx.Clip.overrides = over;
                    EditorUtility.SetDirty(ctx.Clip);
                }
            }
        }

        internal static void AlignScene(CameraPose pose)
        {
            var view = SceneView.lastActiveSceneView;
            if (view == null)
                return;
            float distance = Mathf.Max(0.5f, view.cameraDistance);
            view.rotation = pose.Rotation;
            view.pivot = pose.Position + pose.Rotation * Vector3.forward * distance;
            view.Repaint();
        }

        internal static void SampleFromScene(PreviewContext ctx)
        {
            var view = SceneView.lastActiveSceneView;
            if (view == null || view.camera == null)
                return;
            Vector3 camPos = view.camera.transform.position;
            var p = ctx.Params;
            switch (ctx.Shot.rigKind)
            {
                case RigKind.Static:
                    p.A = Quaternion.Inverse(ctx.AnchorRot) * (camPos - ctx.Anchor);
                    WriteRig(ctx, p, "从视口采样静态机位");
                    break;
                case RigKind.DollyTrack:
                    if ((camPos - p.A).sqrMagnitude <= (camPos - p.B).sqrMagnitude)
                        p.A = camPos;
                    else
                        p.B = camPos;
                    WriteRig(ctx, p, "从视口采样轨道端点");
                    break;
                case RigKind.Orbit:
                {
                    Vector3 center = ctx.FollowSample.Valid ? ctx.FollowSample.Position : p.B;
                    Vector3 flat = camPos - center;
                    p.P3 = flat.y;
                    flat.y = 0f;
                    p.P2 = Mathf.Max(0.2f, flat.magnitude);
                    float ang = Mathf.Atan2(flat.x, flat.z) * Mathf.Rad2Deg;
                    p.P0 = ang - p.P1 * ctx.LocalTime;
                    WriteRig(ctx, p, "从视口采样环绕");
                    break;
                }
                case RigKind.PushPull:
                {
                    Vector3 back = ctx.FollowSample.Valid ? -(ctx.AnchorRot * Vector3.forward) : Vector3.back;
                    if (back.sqrMagnitude < 1e-6f)
                        back = Vector3.back;
                    back.Normalize();
                    float dist = Mathf.Max(0.2f, Vector3.Dot(camPos - ctx.Anchor, back));
                    if (ctx.LocalTime < ctx.Duration * 0.5f)
                        p.P0 = dist;
                    else
                        p.P1 = dist;
                    p.P2 = camPos.y - ctx.Anchor.y;
                    WriteRig(ctx, p, "从视口采样推拉");
                    break;
                }
                case RigKind.Crane:
                {
                    Vector3 origin = ctx.FollowSample.Valid ? ctx.FollowSample.Position : Vector3.zero;
                    if (ctx.LocalTime < ctx.Duration * 0.5f)
                        p.A = camPos - origin;
                    else
                        p.B = camPos - origin;
                    WriteRig(ctx, p, "从视口采样摇臂");
                    break;
                }
                case RigKind.Shoulder:
                {
                    p.P1 = camPos.y - ctx.Anchor.y;
                    Vector3 horizontal = camPos - ctx.Anchor - Vector3.up * p.P1;
                    horizontal -= ctx.AnchorRot * (Vector3.back * 0.35f);
                    Vector3 local = Quaternion.Inverse(ctx.AnchorRot) * horizontal;
                    p.P0 = Mathf.Abs(local.x);
                    p.I0 = local.x >= 0f ? 1 : -1;
                    WriteRig(ctx, p, "从视口采样过肩");
                    break;
                }
                case RigKind.SplineDolly:
                    if (ctx.Clip.spline != null && ctx.Clip.spline.knots != null && ctx.Clip.spline.knots.Length > 0)
                    {
                        int nearest = 0;
                        float best = float.MaxValue;
                        for (int i = 0; i < ctx.Clip.spline.knots.Length; i++)
                        {
                            float d = (ctx.Clip.spline.knots[i] - camPos).sqrMagnitude;
                            if (d < best)
                            {
                                best = d;
                                nearest = i;
                            }
                        }
                        Undo.RecordObject(ctx.Clip.spline, "从视口采样样条点");
                        ctx.Clip.spline.knots[nearest] = camPos;
                        EditorUtility.SetDirty(ctx.Clip.spline);
                    }
                    break;
            }
        }

        static void TryHookTimelineButton()
        {
            var stateProp = typeof(TimelineEditor).GetProperty("state", BindingFlags.NonPublic | BindingFlags.Static);
            if (stateProp == null)
                return;
            var state = stateProp.GetValue(null, null);
            if (state == null || ReferenceEquals(state, s_HookedTimelineState))
                return;
            var evt = state.GetType().GetEvent("windowOnGuiStarted", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (evt == null)
                return;
            var handlerType = evt.EventHandlerType;
            var invoke = handlerType.GetMethod("Invoke");
            if (invoke == null)
                return;
            var parameters = invoke.GetParameters();
            if (parameters.Length != 2)
                return;
            var p0 = Expression.Parameter(parameters[0].ParameterType, "s");
            var p1 = Expression.Parameter(parameters[1].ParameterType, "e");
            var call = Expression.Call(typeof(CineShotSceneEditor).GetMethod("DrawTimelineOpenButton", BindingFlags.NonPublic | BindingFlags.Static));
            var lambda = Expression.Lambda(handlerType, call, p0, p1);
            evt.AddEventHandler(state, lambda.Compile());
            s_HookedTimelineState = state;
        }

        static void DrawTimelineOpenButton()
        {
            var clip = TimelineEditor.selectedClip;
            if (clip == null || !(clip.asset is CineShotClip))
                return;
            var window = TimelineEditor.GetWindow();
            if (window == null)
                return;
            var rect = new Rect(window.position.width - 132f, 1f, 124f, 17f);
            if (GUI.Button(rect, "打开镜头配置"))
                CineShotClipConfigWindow.Open();
        }

        internal static string RigLabel(RigKind kind)
        {
            switch (kind)
            {
                case RigKind.Static: return "静态";
                case RigKind.DollyTrack: return "轨道";
                case RigKind.Orbit: return "环绕";
                case RigKind.PushPull: return "推拉";
                case RigKind.Crane: return "摇臂";
                case RigKind.Shoulder: return "过肩";
                case RigKind.Handheld: return "手持";
                case RigKind.SplineDolly: return "样条";
                default: return kind.ToString();
            }
        }
    }
}
