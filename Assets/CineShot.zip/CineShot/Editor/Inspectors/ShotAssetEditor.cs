using CineShot.Core;
using UnityEditor;
using UnityEngine;

namespace CineShot.Editor
{
    [CustomEditor(typeof(ShotAsset))]
    public sealed class ShotAssetEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            EditorGUILayout.HelpBox(
                "镜头资产是库级可复用定义。场景目标不在这里绑定：请到 Timeline 的 CineShotClip 上直接指定注视/跟随 Transform。",
                MessageType.Info);

            var idProp = serializedObject.FindProperty("m_Id");
            using (new EditorGUI.DisabledScope(true))
                EditorGUILayout.PropertyField(idProp, new GUIContent("编号（只读）"));

            Draw("displayName", "显示名称");
            Draw("rigKind", "机位类型");
            EditorGUILayout.PropertyField(serializedObject.FindProperty("rigParams"), new GUIContent("机位参数"), true);
            Draw("defaultDuration", "默认时长（秒）");
            Draw("targetBinding", "目标偏移（相对已绑定 Transform）");
            Draw("compositionOffset", "构图偏移");
            Draw("fov", "视场角 FOV");
            Draw("nearClip", "近裁剪面");
            Draw("farClip", "远裁剪面");
            Draw("focusMode", "焦点模式");
            Draw("focusDistance", "焦点距离");
            Draw("easeIn", "淡入曲线");
            Draw("easeOut", "淡出曲线");
            Draw("priority", "优先级");
            EditorGUILayout.PropertyField(serializedObject.FindProperty("tags"), new GUIContent("标签"), true);
            Draw("overrideMask", "默认可覆写掩码");
            EditorGUILayout.PropertyField(serializedObject.FindProperty("handheld"), new GUIContent("手持层"), true);
            Draw("impulseExclusive", "与震屏 Impulse 互斥");
            EditorGUILayout.PropertyField(serializedObject.FindProperty("matchPoint"), new GUIContent("匹配帧锚点"), true);
            Draw("parentGuid", "父变体编号");

            serializedObject.ApplyModifiedProperties();
        }

        void Draw(string prop, string label)
        {
            var p = serializedObject.FindProperty(prop);
            if (p != null)
                EditorGUILayout.PropertyField(p, new GUIContent(label));
        }
    }
}
