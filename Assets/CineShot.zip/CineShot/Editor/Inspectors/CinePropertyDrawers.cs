using CineShot.Core;
using UnityEditor;
using UnityEngine;

namespace CineShot.Editor
{
    [CustomPropertyDrawer(typeof(ShotOverrideMask))]
    public sealed class ShotOverrideMaskDrawer : PropertyDrawer
    {
        static readonly ShotOverrideMask[] k_Flags =
        {
            ShotOverrideMask.RigParams,
            ShotOverrideMask.Composition,
            ShotOverrideMask.Optics,
            ShotOverrideMask.Focus,
            ShotOverrideMask.Easing,
            ShotOverrideMask.PriorityTags,
            ShotOverrideMask.TargetOffset
        };

        static readonly string[] k_Names =
        {
            "机位参数",
            "构图",
            "光学（FOV/裁剪）",
            "焦点",
            "缓动",
            "优先级与标签",
            "目标偏移"
        };

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            return EditorGUIUtility.singleLineHeight * (k_Flags.Length + 1) + 4f;
        }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            var line = new Rect(position.x, position.y, position.width, EditorGUIUtility.singleLineHeight);
            EditorGUI.LabelField(line, label.text == "Mask" || string.IsNullOrEmpty(label.text) ? "覆写掩码" : label.text);
            int value = property.intValue;
            EditorGUI.indentLevel++;
            for (int i = 0; i < k_Flags.Length; i++)
            {
                line.y += EditorGUIUtility.singleLineHeight + 1f;
                bool on = (value & (int)k_Flags[i]) != 0;
                bool next = EditorGUI.ToggleLeft(line, k_Names[i], on);
                if (next != on)
                {
                    if (next) value |= (int)k_Flags[i];
                    else value &= ~(int)k_Flags[i];
                }
            }
            EditorGUI.indentLevel--;
            property.intValue = value;
        }
    }

    [CustomPropertyDrawer(typeof(CineSequenceAsset.TimelineAssetRef))]
    public sealed class TimelineAssetRefDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            var asset = property.FindPropertyRelative("asset");
            EditorGUI.PropertyField(position, asset, new GUIContent(string.IsNullOrEmpty(label.text) ? "Timeline 资产" : label.text));
        }
    }

    [CustomPropertyDrawer(typeof(RigParams))]
    public sealed class RigParamsDrawer : PropertyDrawer
    {
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            if (!property.isExpanded)
                return EditorGUIUtility.singleLineHeight;
            return EditorGUIUtility.singleLineHeight * 10f + 8f;
        }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            RigKind kind = ResolveKind(property);
            label = new GUIContent(string.IsNullOrEmpty(label.text) ? "机位参数" : label.text, RigHint(kind));

            var line = new Rect(position.x, position.y, position.width, EditorGUIUtility.singleLineHeight);
            property.isExpanded = EditorGUI.Foldout(line, property.isExpanded, label, true);
            if (!property.isExpanded)
                return;

            EditorGUI.indentLevel++;
            float y = line.yMax + 2f;
            float h = EditorGUIUtility.singleLineHeight;
            float w = position.width;

            EditorGUI.HelpBox(new Rect(position.x, y, w, h * 1.6f), RigHint(kind), MessageType.None);
            y += h * 1.6f + 2f;

            string a, b, p0, p1, p2, p3, i0, i1;
            LabelsFor(kind, out a, out b, out p0, out p1, out p2, out p3, out i0, out i1);

            Draw(ref y, w, position.x, property.FindPropertyRelative("A"), a);
            Draw(ref y, w, position.x, property.FindPropertyRelative("B"), b);
            Draw(ref y, w, position.x, property.FindPropertyRelative("P0"), p0);
            Draw(ref y, w, position.x, property.FindPropertyRelative("P1"), p1);
            Draw(ref y, w, position.x, property.FindPropertyRelative("P2"), p2);
            Draw(ref y, w, position.x, property.FindPropertyRelative("P3"), p3);
            Draw(ref y, w, position.x, property.FindPropertyRelative("I0"), i0);
            Draw(ref y, w, position.x, property.FindPropertyRelative("I1"), i1);
            EditorGUI.indentLevel--;
        }

        static void Draw(ref float y, float w, float x, SerializedProperty p, string label)
        {
            if (p == null) return;
            EditorGUI.PropertyField(new Rect(x, y, w, EditorGUIUtility.singleLineHeight), p, new GUIContent(label));
            y += EditorGUIUtility.singleLineHeight + 1f;
        }

        static RigKind ResolveKind(SerializedProperty property)
        {
            if (property.propertyPath.IndexOf("handheld") >= 0 || property.propertyPath.EndsWith("parameters"))
                return RigKind.Handheld;

            string parentPath = property.propertyPath;
            int dot = parentPath.LastIndexOf('.');
            string prefix = dot >= 0 ? parentPath.Substring(0, dot + 1) : string.Empty;
            var kindProp = property.serializedObject.FindProperty(prefix + "rigKind");
            if (kindProp == null && prefix.Length > 0)
            {
                // ShotOverride 等嵌套：再往上一层找
                int prev = prefix.TrimEnd('.').LastIndexOf('.');
                string up = prev >= 0 ? parentPath.Substring(0, prev + 1) : string.Empty;
                kindProp = property.serializedObject.FindProperty(up + "rigKind");
            }
            if (kindProp != null && kindProp.propertyType == SerializedPropertyType.Enum)
                return (RigKind)kindProp.enumValueIndex;
            return RigKind.Static;
        }

        static string RigHint(RigKind kind)
        {
            switch (kind)
            {
                case RigKind.Static: return "静态：相对锚点偏移，可用偏航/俯仰微调朝向。";
                case RigKind.DollyTrack: return "轨道：沿 A→B 移动。侧向和高度都是相对轨道点的偏移，不是世界坐标。";
                case RigKind.Orbit: return "环绕：有跟随目标时绕它转，圆心跟着走。没有跟随目标时绕 B（世界坐标）转，圆留在原地。";
                case RigKind.PushPull: return "推拉：距离由近到远（或相反），可联动 FOV。";
                case RigKind.Crane: return "摇臂：A、B 是起点和终点。设了跟随目标时整条轨迹跟着它移动，没设时停在世界坐标。有注视目标时对准该点。";
                case RigKind.Shoulder: return "过肩：I0≥0 右肩，<0 左肩。";
                case RigKind.Handheld: return "手持：噪声振幅/频率/角抖动。";
                case RigKind.SplineDolly: return "样条：片段时间内从第一个控制点走到最后一个。无样条时退化为 A→B。";
                default: return "机位参数随 Rig 类型语义变化。";
            }
        }

        static void LabelsFor(RigKind kind,
            out string a, out string b, out string p0, out string p1, out string p2, out string p3, out string i0, out string i1)
        {
            a = "向量 A"; b = "向量 B";
            p0 = "参数 P0"; p1 = "参数 P1"; p2 = "参数 P2"; p3 = "参数 P3";
            i0 = "整数 I0"; i1 = "整数 I1";
            switch (kind)
            {
                case RigKind.Static:
                    a = "相对偏移 A";
                    p0 = "偏航角（度）";
                    p1 = "俯仰角（度）";
                    break;
                case RigKind.DollyTrack:
                    a = "轨道起点 A";
                    b = "轨道终点 B";
                    p0 = "前馈预测时间（秒）";
                    p1 = "相对轨道侧向";
                    p2 = "相对轨道高度";
                    p3 = "Dutch 倾角";
                    break;
                case RigKind.Orbit:
                    a = "目标 FOV（用 X）";
                    b = "无跟随时的圆心";
                    p0 = "起始方位角（度）";
                    p1 = "角速度（度/秒）";
                    p2 = "半径";
                    p3 = "高度";
                    break;
                case RigKind.PushPull:
                    a = "结束 FOV（用 X）";
                    p0 = "起始距离";
                    p1 = "结束距离";
                    p2 = "高度";
                    p3 = "启用 FOV 联动（>0.5）";
                    break;
                case RigKind.Crane:
                    a = "起点（相对跟随）";
                    b = "终点（相对跟随）";
                    p0 = "弧线偏移 X";
                    p1 = "弧线偏移 Y";
                    p2 = "弧线偏移 Z";
                    p3 = "（保留）";
                    i0 = "（保留）";
                    break;
                case RigKind.Shoulder:
                    p0 = "肩侧偏移";
                    p1 = "肩高";
                    p2 = "注视偏航微调";
                    p3 = "Dutch 倾角";
                    i0 = "左右肩（≥0 右 / <0 左）";
                    break;
                case RigKind.Handheld:
                    p0 = "位置振幅";
                    p1 = "噪声频率";
                    p2 = "俯仰/方位抖动";
                    p3 = "滚动抖动";
                    break;
                case RigKind.SplineDolly:
                    a = "备用起点 A";
                    b = "备用终点 B";
                    p0 = "（保留）";
                    p1 = "（保留，不参与行程）";
                    p2 = "前馈预测时间";
                    p3 = "备用高度";
                    i0 = "（保留）";
                    break;
            }
        }
    }

    [CustomPropertyDrawer(typeof(TargetBinding))]
    public sealed class TargetBindingDrawer : PropertyDrawer
    {
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            return property.isExpanded
                ? EditorGUIUtility.singleLineHeight * 5f + 6f
                : EditorGUIUtility.singleLineHeight;
        }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            var line = new Rect(position.x, position.y, position.width, EditorGUIUtility.singleLineHeight);
            property.isExpanded = EditorGUI.Foldout(line, property.isExpanded, new GUIContent("目标绑定"), true);
            if (!property.isExpanded) return;
            EditorGUI.indentLevel++;
            float y = line.yMax + 2f;
            float h = EditorGUIUtility.singleLineHeight;
            EditorGUI.PropertyField(new Rect(position.x, y, position.width, h), property.FindPropertyRelative("mode"), new GUIContent("绑定模式"));
            y += h + 1f;
            EditorGUI.PropertyField(new Rect(position.x, y, position.width, h), property.FindPropertyRelative("lookAtOffset"), new GUIContent("注视偏移"));
            y += h + 1f;
            EditorGUI.PropertyField(new Rect(position.x, y, position.width, h), property.FindPropertyRelative("followOffset"), new GUIContent("跟随偏移"));
            y += h + 1f;
            EditorGUI.PropertyField(new Rect(position.x, y, position.width, h), property.FindPropertyRelative("damping"), new GUIContent("阻尼（秒）"));
            EditorGUI.indentLevel--;
        }
    }

    [CustomPropertyDrawer(typeof(HandheldLayer))]
    public sealed class HandheldLayerDrawer : PropertyDrawer
    {
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            if (!property.isExpanded)
                return EditorGUIUtility.singleLineHeight;
            var parms = property.FindPropertyRelative("parameters");
            float ph = parms != null ? EditorGUI.GetPropertyHeight(parms, true) : EditorGUIUtility.singleLineHeight;
            return EditorGUIUtility.singleLineHeight * 2f + ph + 4f;
        }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            var line = new Rect(position.x, position.y, position.width, EditorGUIUtility.singleLineHeight);
            property.isExpanded = EditorGUI.Foldout(line, property.isExpanded, new GUIContent("手持层"), true);
            if (!property.isExpanded) return;
            EditorGUI.indentLevel++;
            float y = line.yMax + 2f;
            EditorGUI.PropertyField(new Rect(position.x, y, position.width, EditorGUIUtility.singleLineHeight),
                property.FindPropertyRelative("enabled"), new GUIContent("启用手持抖动"));
            y += EditorGUIUtility.singleLineHeight + 2f;
            var parms = property.FindPropertyRelative("parameters");
            float ph = EditorGUI.GetPropertyHeight(parms, true);
            EditorGUI.PropertyField(new Rect(position.x, y, position.width, ph), parms, new GUIContent("抖动参数"), true);
            EditorGUI.indentLevel--;
        }
    }

    [CustomPropertyDrawer(typeof(MatchPoint))]
    public sealed class MatchPointDrawer : PropertyDrawer
    {
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            return property.isExpanded
                ? EditorGUIUtility.singleLineHeight * 5f + 6f
                : EditorGUIUtility.singleLineHeight;
        }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            var line = new Rect(position.x, position.y, position.width, EditorGUIUtility.singleLineHeight);
            property.isExpanded = EditorGUI.Foldout(line, property.isExpanded, new GUIContent("匹配帧锚点"), true);
            if (!property.isExpanded) return;
            EditorGUI.indentLevel++;
            float y = line.yMax + 2f;
            float h = EditorGUIUtility.singleLineHeight;
            EditorGUI.PropertyField(new Rect(position.x, y, position.width, h), property.FindPropertyRelative("valid"), new GUIContent("启用匹配点"));
            y += h + 1f;
            EditorGUI.PropertyField(new Rect(position.x, y, position.width, h), property.FindPropertyRelative("position"), new GUIContent("位置"));
            y += h + 1f;
            EditorGUI.PropertyField(new Rect(position.x, y, position.width, h), property.FindPropertyRelative("rotation"), new GUIContent("旋转"));
            y += h + 1f;
            EditorGUI.PropertyField(new Rect(position.x, y, position.width, h), property.FindPropertyRelative("fov"), new GUIContent("视场角"));
            EditorGUI.indentLevel--;
        }
    }

    [CustomPropertyDrawer(typeof(ShotOverride))]
    public sealed class ShotOverrideDrawer : PropertyDrawer
    {
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            if (!property.isExpanded)
                return EditorGUIUtility.singleLineHeight;
            float h = EditorGUIUtility.singleLineHeight + 4f;
            h += EditorGUI.GetPropertyHeight(property.FindPropertyRelative("mask"), true);
            h += EditorGUI.GetPropertyHeight(property.FindPropertyRelative("rigParams"), true);
            h += EditorGUI.GetPropertyHeight(property.FindPropertyRelative("lookAtOffset"), true);
            h += EditorGUI.GetPropertyHeight(property.FindPropertyRelative("followOffset"), true);
            h += EditorGUIUtility.singleLineHeight * 8f;
            h += EditorGUI.GetPropertyHeight(property.FindPropertyRelative("easeIn"), true);
            h += EditorGUI.GetPropertyHeight(property.FindPropertyRelative("easeOut"), true);
            return h + 20f;
        }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            var line = new Rect(position.x, position.y, position.width, EditorGUIUtility.singleLineHeight);
            property.isExpanded = EditorGUI.Foldout(line, property.isExpanded, new GUIContent("片段覆写"), true);
            if (!property.isExpanded) return;
            EditorGUI.indentLevel++;
            float y = line.yMax + 2f;
            float w = position.width;
            float x = position.x;
            float sh = EditorGUIUtility.singleLineHeight;

            var mask = property.FindPropertyRelative("mask");
            float mh = EditorGUI.GetPropertyHeight(mask, true);
            EditorGUI.PropertyField(new Rect(x, y, w, mh), mask, new GUIContent("覆写掩码"), true);
            y += mh + 2f;

            var rig = property.FindPropertyRelative("rigParams");
            float rh = EditorGUI.GetPropertyHeight(rig, true);
            EditorGUI.PropertyField(new Rect(x, y, w, rh), rig, new GUIContent("机位参数覆写"), true);
            y += rh + 2f;

            var look = property.FindPropertyRelative("lookAtOffset");
            float lh = EditorGUI.GetPropertyHeight(look, true);
            EditorGUI.PropertyField(new Rect(x, y, w, lh), look, new GUIContent("注视偏移"));
            y += lh + 1f;
            var follow = property.FindPropertyRelative("followOffset");
            float fh = EditorGUI.GetPropertyHeight(follow, true);
            EditorGUI.PropertyField(new Rect(x, y, w, fh), follow, new GUIContent("跟随偏移"));
            y += fh + 1f;

            EditorGUI.PropertyField(new Rect(x, y, w, sh), property.FindPropertyRelative("compositionOffset"), new GUIContent("构图偏移"));
            y += sh + 1f;
            EditorGUI.PropertyField(new Rect(x, y, w, sh), property.FindPropertyRelative("fov"), new GUIContent("视场角"));
            y += sh + 1f;
            EditorGUI.PropertyField(new Rect(x, y, w, sh), property.FindPropertyRelative("nearClip"), new GUIContent("近裁剪面"));
            y += sh + 1f;
            EditorGUI.PropertyField(new Rect(x, y, w, sh), property.FindPropertyRelative("farClip"), new GUIContent("远裁剪面"));
            y += sh + 1f;
            EditorGUI.PropertyField(new Rect(x, y, w, sh), property.FindPropertyRelative("focusMode"), new GUIContent("焦点模式"));
            y += sh + 1f;
            EditorGUI.PropertyField(new Rect(x, y, w, sh), property.FindPropertyRelative("focusDistance"), new GUIContent("焦点距离"));
            y += sh + 1f;
            EditorGUI.PropertyField(new Rect(x, y, w, sh), property.FindPropertyRelative("easeIn"), new GUIContent("淡入曲线"));
            y += sh + 1f;
            EditorGUI.PropertyField(new Rect(x, y, w, sh), property.FindPropertyRelative("easeOut"), new GUIContent("淡出曲线"));
            y += sh + 1f;
            EditorGUI.PropertyField(new Rect(x, y, w, sh), property.FindPropertyRelative("priority"), new GUIContent("优先级"));
            EditorGUI.indentLevel--;
        }
    }

    [CustomPropertyDrawer(typeof(StoryboardRow))]
    public sealed class StoryboardRowDrawer : PropertyDrawer
    {
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            return property.isExpanded
                ? EditorGUIUtility.singleLineHeight * 12f + 10f
                : EditorGUIUtility.singleLineHeight;
        }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            var line = new Rect(position.x, position.y, position.width, EditorGUIUtility.singleLineHeight);
            string title = label.text;
            if (string.IsNullOrEmpty(title) || title.StartsWith("Element"))
                title = "分镜行";
            property.isExpanded = EditorGUI.Foldout(line, property.isExpanded, new GUIContent(title), true);
            if (!property.isExpanded) return;
            EditorGUI.indentLevel++;
            float y = line.yMax + 2f;
            float h = EditorGUIUtility.singleLineHeight;
            float w = position.width;
            float x = position.x;
            Draw(ref y, x, w, h, property, "shotGuid", "镜头 GUID");
            Draw(ref y, x, w, h, property, "rowIndex", "行索引");
            Draw(ref y, x, w, h, property, "duration", "时长（秒）");
            Draw(ref y, x, w, h, property, "gap", "间隔（秒）");
            Draw(ref y, x, w, h, property, "blendMode", "转场模式");
            Draw(ref y, x, w, h, property, "blendIn", "淡入时长");
            Draw(ref y, x, w, h, property, "blendOut", "淡出时长");
            Draw(ref y, x, w, h, property, "timeScale", "时间缩放");
            Draw(ref y, x, w, h, property, "loop", "循环");
            Draw(ref y, x, w, h, property, "hasRigOverride", "覆写机位类型");
            Draw(ref y, x, w, h, property, "rigOverride", "机位类型覆写");
            Draw(ref y, x, w, h, property, "note", "备注");
            EditorGUI.indentLevel--;
        }

        static void Draw(ref float y, float x, float w, float h, SerializedProperty root, string name, string label)
        {
            var p = root.FindPropertyRelative(name);
            if (p == null) return;
            EditorGUI.PropertyField(new Rect(x, y, w, h), p, new GUIContent(label));
            y += h + 1f;
        }
    }
}
