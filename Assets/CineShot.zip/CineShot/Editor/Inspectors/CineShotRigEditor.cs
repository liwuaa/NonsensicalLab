using System.Collections.Generic;
using CineShot.Core;
using UnityEditor;
using UnityEngine;

namespace CineShot.Editor
{
    [CustomEditor(typeof(CineShotRig))]
    public sealed class CineShotRigEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            EditorGUILayout.HelpBox(
                "场景运镜绑定点。Timeline 的 CineShotTrack 应绑定到本组件。\n" +
                "输出虚拟相机：运镜写位姿的那台 Cinemachine 相机，播放时提高优先级接管主相机。\n" +
                "游戏虚拟相机：玩家/玩法相机；打断运镜时会从输出位姿混合过去，然后交回控制权。",
                MessageType.Info);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_OutputVcam"),
                new GUIContent("输出虚拟相机", "运镜结果写入这里，并在播放时接管主相机画面。"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_GameVcam"),
                new GUIContent("游戏虚拟相机", "打断/结束运镜时混合回这台相机。"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_FocusProfile"), new GUIContent("焦点配置"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_MinTargetDistance"), new GUIContent("与目标最小距离"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_FallbackCamera"), new GUIContent("回退主相机"));
            serializedObject.ApplyModifiedProperties();

            var rig = (CineShotRig)target;
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("运行时", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("输出适配器", rig.Output != null ? rig.Output.GetType().Name : "无");
            EditorGUILayout.LabelField("已有位姿", rig.HasPose ? "是" : "否");
            if (GUILayout.Button("重建输出适配器"))
            {
                rig.RebuildOutputs();
                EditorUtility.SetDirty(rig);
            }
        }
    }

    [CustomEditor(typeof(CineShotPlayer))]
    public sealed class CineShotPlayerEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            EditorGUILayout.HelpBox(
                "播放包装器：驱动 CinePlayer 四状态机（Idle / Playing / Interrupted / BlendingOut）。快捷键在 DemoHUD 中处理。",
                MessageType.Info);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_Director"), new GUIContent("Timeline 导演"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_Rig"), new GUIContent("运镜绑定"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_DefaultInterruptBlend"), new GUIContent("默认打断混合时长（秒）"));
            serializedObject.ApplyModifiedProperties();

            var player = (CineShotPlayer)target;
            if (player.Player != null)
            {
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("当前状态", StateZh(player.Player.State));
                EditorGUILayout.LabelField("当前镜头", player.Player.CurrentShot != null ? player.Player.CurrentShot.displayName : "-");
            }
        }

        static string StateZh(CineState state)
        {
            switch (state)
            {
                case CineState.Idle: return "空闲";
                case CineState.Playing: return "播放中";
                case CineState.PausedResumable: return "已打断可续播";
                case CineState.BlendingOut: return "交权混合中";
                default: return state.ToString();
            }
        }
    }

    [CustomEditor(typeof(CineShotClip))]
    public sealed class CineShotClipInspector : UnityEditor.Editor
    {
        static bool s_LayFoldout;

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            if (GUILayout.Button("打开镜头配置"))
                CineShotClipConfigWindow.Open();
            EditorGUILayout.HelpBox(
                "注视和跟随可以不绑。环绕没绑跟随时绕 B 转，圆留在原地；摇臂没绑跟随时轨迹停在世界坐标，绑了就整条跟着走。Scene 手柄默认改本片段覆写。\n" +
                "转场模式选「混合」时，片段开头约 0.5 秒会从上一个镜头过渡过来。硬切则直接跳。",
                MessageType.Info);
            DrawShotPopup(serializedObject.FindProperty("shot"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("overrides"), new GUIContent("片段覆写"), true);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("lookAt"), new GUIContent("注视目标"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("follow"), new GUIContent("跟随目标"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("easeIn"), new GUIContent("淡入曲线"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("easeOut"), new GUIContent("淡出曲线"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("blendMode"), new GUIContent("转场模式"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("spline"), new GUIContent("样条资产"));
            s_LayFoldout = EditorGUILayout.Foldout(s_LayFoldout, "分镜铺轨", true);
            if (s_LayFoldout)
            {
                EditorGUILayout.HelpBox("铺轨匹配键是分镜表铺到 Timeline 时认出同一条片段的内部键，形式是镜头编号#行号，不是镜头参数。", MessageType.None);
                EditorGUILayout.PropertyField(serializedObject.FindProperty("matchKey"), new GUIContent("铺轨匹配键"));
                using (new EditorGUI.DisabledScope(true))
                {
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("sourceHash"), new GUIContent("源哈希"));
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("lastAppliedDuration"), new GUIContent("上次铺轨时长"));
                }
            }
            serializedObject.ApplyModifiedProperties();
        }

        static void DrawShotPopup(SerializedProperty shotProp)
        {
            var current = shotProp.objectReferenceValue as ShotAsset;
            string[] guids = AssetDatabase.FindAssets("t:ShotAsset");
            var assets = new List<ShotAsset>();
            var labels = new List<string>();
            assets.Add(null);
            labels.Add("（无）");
            int selected = 0;
            for (int i = 0; i < guids.Length; i++)
            {
                var asset = AssetDatabase.LoadAssetAtPath<ShotAsset>(AssetDatabase.GUIDToAssetPath(guids[i]));
                if (asset == null)
                    continue;
                assets.Add(asset);
                labels.Add(string.IsNullOrEmpty(asset.displayName) ? asset.name : asset.displayName);
                if (asset == current)
                    selected = assets.Count - 1;
            }
            if (current != null && selected == 0)
            {
                assets.Add(current);
                labels.Add(string.IsNullOrEmpty(current.displayName) ? current.name : current.displayName);
                selected = assets.Count - 1;
            }
            int next = EditorGUILayout.Popup(new GUIContent("镜头资产"), selected, labels.ToArray());
            if (next != selected)
                shotProp.objectReferenceValue = next <= 0 ? null : assets[next];
            var row = GUILayoutUtility.GetLastRect();
            var evt = Event.current;
            if (evt.type == EventType.ContextClick && row.Contains(evt.mousePosition))
            {
                var asset = selected > 0 ? assets[selected] : null;
                var menu = new GenericMenu();
                if (asset != null)
                    menu.AddItem(new GUIContent("选中镜头资产"), false, () => SelectShotAsset(asset));
                else
                    menu.AddDisabledItem(new GUIContent("选中镜头资产"));
                menu.ShowAsContext();
                evt.Use();
            }
        }

        static void SelectShotAsset(ShotAsset asset)
        {
            Selection.activeObject = asset;
            EditorGUIUtility.PingObject(asset);
        }
    }
}
