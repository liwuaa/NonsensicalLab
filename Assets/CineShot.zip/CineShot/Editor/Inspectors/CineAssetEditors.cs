using CineShot.Core;
using CineShot.Samples;
using UnityEditor;
using UnityEngine;

namespace CineShot.Editor
{
    [CustomEditor(typeof(FocusProfile))]
    public sealed class FocusProfileEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            EditorGUILayout.HelpBox(
                "焦点配置：控制对焦阻尼、限速与 URP DepthOfField 参数。运行时由 UrpFocusOutput 写入 Volume（只创建一次）。",
                MessageType.Info);
            Draw("dofMode", "景深模式");
            Draw("damping", "对焦阻尼（1/秒）");
            Draw("maxFocusSpeed", "最大对焦速度（米/秒）");
            Draw("pullDuration", "拉焦时长（秒）");
            Draw("aperture", "光圈 F 值");
            Draw("focalLength", "焦距（毫米）");
            Draw("bladeCount", "光圈叶片数");
            Draw("focusLayerMask", "对焦射线层遮罩");
            Draw("hyperfocalCircleOfConfusion", "超焦距弥散圈");
            serializedObject.ApplyModifiedProperties();
        }

        void Draw(string prop, string label)
        {
            var p = serializedObject.FindProperty(prop);
            if (p != null)
                EditorGUILayout.PropertyField(p, new GUIContent(label));
        }
    }

    [CustomEditor(typeof(EasingAsset))]
    public sealed class EasingAssetEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            EditorGUILayout.HelpBox(
                "缓动资产会烘焙为 65 点查找表，热路径不调用 AnimationCurve.Evaluate。改完类型或曲线后会自动重建。",
                MessageType.Info);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("kind"), new GUIContent("缓动类型"));
            var kind = (EasingAsset.EaseKind)serializedObject.FindProperty("kind").enumValueIndex;
            using (new EditorGUI.DisabledScope(kind != EasingAsset.EaseKind.Custom))
                EditorGUILayout.PropertyField(serializedObject.FindProperty("custom"), new GUIContent("自定义曲线"));
            if (GUILayout.Button("重建查找表"))
            {
                foreach (var t in targets)
                {
                    var ease = t as EasingAsset;
                    if (ease != null)
                    {
                        ease.Rebuild();
                        EditorUtility.SetDirty(ease);
                    }
                }
            }
            serializedObject.ApplyModifiedProperties();
            if (GUI.changed)
            {
                foreach (var t in targets)
                {
                    var ease = t as EasingAsset;
                    if (ease != null) ease.Rebuild();
                }
            }
        }
    }

    [CustomEditor(typeof(CineSpline))]
    public sealed class CineSplineEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            EditorGUILayout.HelpBox(
                "自研 Catmull-Rom 样条，不依赖 Splines 包。SplineDolly 机位通过 CineShotClip.spline 引用本资产。",
                MessageType.Info);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("knots"), new GUIContent("控制点（Knots）"), true);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("tension"), new GUIContent("张力（0~1）"));
            serializedObject.ApplyModifiedProperties();
        }
    }

    [CustomEditor(typeof(CineSequenceAsset))]
    public sealed class CineSequenceAssetEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            EditorGUILayout.HelpBox(
                "分镜资产描述镜头序列。可用「Tools/Cine/分镜表」编辑，并幂等铺到 Timeline 的 CineShotTrack。",
                MessageType.Info);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("timeline"), new GUIContent("关联 Timeline"), true);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("rows"), new GUIContent("分镜行"), true);
            serializedObject.ApplyModifiedProperties();
            if (GUILayout.Button("打开分镜表窗口"))
                StoryboardWindow.Open();
        }
    }

    [CustomEditor(typeof(CineDemoHUD))]
    public sealed class CineDemoHUDEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            EditorGUILayout.HelpBox(
                "示例 HUD：按钮与快捷键（空格/I/R/S）驱动 CineShotPlayer。仅用于演示场景。",
                MessageType.Info);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_Player"), new GUIContent("运镜播放器"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_Status"), new GUIContent("状态文本"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_InterruptBlend"), new GUIContent("打断混合时长（秒）"));
            serializedObject.ApplyModifiedProperties();
        }
    }

    [CustomEditor(typeof(CineFrameProbe))]
    public sealed class CineFrameProbeEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            EditorGUILayout.HelpBox(
                "帧耗时探针：预热后采样，输出 P50/P95/Max 与 GC.Alloc。建议在 Development Build 的 Demo_Perf_Baseline 使用。",
                MessageType.Info);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("WarmupFrames"), new GUIContent("预热帧数"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("SampleFrames"), new GUIContent("采样帧数"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("ThresholdP95Ms"), new GUIContent("P95 阈值（毫秒）"));
            serializedObject.ApplyModifiedProperties();
            var probe = (CineFrameProbe)target;
            EditorGUILayout.LabelField("最近 P95", probe.LastP95.ToString("F4") + " ms");
            EditorGUILayout.LabelField("累计 GC", probe.LastGcTotal.ToString() + " B");
        }
    }
}
