using System.Collections.Generic;
using CineShot.Core;
using UnityEditor;
using UnityEditor.Timeline.Actions;
using UnityEngine;
using UnityEngine.Timeline;

namespace CineShot.Editor
{
    public sealed class CineShotClipConfigWindow : EditorWindow
    {
        [MenuItem("Tools/Cine/镜头配置")]
        public static void Open()
        {
            var win = GetWindow<CineShotClipConfigWindow>("镜头配置");
            win.Show();
            win.Focus();
        }

        void OnInspectorUpdate()
        {
            Repaint();
        }

        void OnGUI()
        {
            var ctx = CineShotSceneEditor.BuildContext();
            if (ctx == null || ctx.Shot == null)
            {
                EditorGUILayout.HelpBox("请先在 Timeline 中选中一个 CineShot 片段。", MessageType.Info);
                return;
            }

            EditorGUILayout.LabelField(ctx.Shot.displayName + "  ·  " + CineShotSceneEditor.RigLabel(ctx.Shot.rigKind), EditorStyles.boldLabel);
            EditorGUILayout.LabelField("预览时间", ctx.LocalTime.ToString("0.00") + " / " + ctx.Duration.ToString("0.00") + " 秒");
            if (ctx.Selected && !ctx.InsidePlayhead && SessionState.GetBool(CineShotSceneEditor.k_FollowKey, true))
                EditorGUILayout.HelpBox("播放头不在此片段内，Scene 正在显示起始帧。", MessageType.None);

            bool writeOverride = SessionState.GetBool(CineShotSceneEditor.k_OverrideKey, true);
            EditorGUILayout.HelpBox(
                writeOverride
                    ? "当前写入：这个片段。机位、视场角、注视偏移只改当前片段；对应覆写没开时会自动打开，并先带上模板里的其余数值。"
                    : "当前写入：镜头模板。机位、视场角、注视偏移都会改 ShotAsset，引用该模板的片段一起变。",
                writeOverride ? MessageType.Info : MessageType.Warning);

            bool writeTemplate = !writeOverride;
            bool nextTemplate = EditorGUILayout.ToggleLeft("改为直接写入镜头模板", writeTemplate);
            if (nextTemplate != writeTemplate)
                SessionState.SetBool(CineShotSceneEditor.k_OverrideKey, !nextTemplate);

            bool follow = SessionState.GetBool(CineShotSceneEditor.k_FollowKey, true);
            bool nextFollow = EditorGUILayout.ToggleLeft("预览时间跟随 Timeline 播放头", follow);
            if (nextFollow != follow)
                SessionState.SetBool(CineShotSceneEditor.k_FollowKey, nextFollow);
            if (!nextFollow)
            {
                float manual = SessionState.GetFloat("CineShot.ManualTime", ctx.LocalTime);
                EditorGUI.BeginChangeCheck();
                manual = EditorGUILayout.Slider("预览时间", manual, 0f, ctx.Duration);
                if (EditorGUI.EndChangeCheck())
                    SessionState.SetFloat("CineShot.ManualTime", manual);
            }

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Scene 对齐镜头"))
                    CineShotSceneEditor.AlignScene(ctx.Pose);
                if (GUILayout.Button("从 Scene 取样"))
                    CineShotSceneEditor.SampleFromScene(ctx);
            }
            if (GUILayout.Button("保存至模板"))
                CineShotSceneEditor.SaveClipToTemplate(ctx);

            DrawParamSliders(ctx);
            if (ctx.Rig == null)
                EditorGUILayout.HelpBox("场景里没有 CineShotRig，只能在 Scene 里看线框。", MessageType.Warning);
        }

        static void DrawParamSliders(CineShotSceneEditor.PreviewContext ctx)
        {
            var p = ctx.Params;
            switch (ctx.Shot.rigKind)
            {
                case RigKind.DollyTrack:
                    if (Field("相对轨道侧向", ref p.P1)) CineShotSceneEditor.WriteRig(ctx, p, "调整轨道侧向");
                    if (Field("相对轨道高度", ref p.P2)) CineShotSceneEditor.WriteRig(ctx, p, "调整轨道高度");
                    break;
                case RigKind.Orbit:
                    if (Field("半径", ref p.P2)) CineShotSceneEditor.WriteRig(ctx, p, "调整环绕半径");
                    if (Field("高度", ref p.P3)) CineShotSceneEditor.WriteRig(ctx, p, "调整环绕高度");
                    EditorGUI.BeginChangeCheck();
                    p.P0 = EditorGUILayout.FloatField("起始角度（度）", p.P0);
                    if (EditorGUI.EndChangeCheck()) CineShotSceneEditor.WriteRig(ctx, p, "调整环绕起始角度");
                    EditorGUI.BeginChangeCheck();
                    p.P1 = EditorGUILayout.FloatField("角速度（度/秒）", p.P1);
                    if (EditorGUI.EndChangeCheck()) CineShotSceneEditor.WriteRig(ctx, p, "调整环绕速度");
                    EditorGUILayout.HelpBox("有跟随目标时绕它转，圆心跟着走。没有跟随目标时绕 B 这个世界坐标转，圆留在原地。", MessageType.None);
                    break;
                case RigKind.PushPull:
                    if (Field("起始距离", ref p.P0)) CineShotSceneEditor.WriteRig(ctx, p, "调整推拉起点");
                    if (Field("结束距离", ref p.P1)) CineShotSceneEditor.WriteRig(ctx, p, "调整推拉终点");
                    break;
                case RigKind.Crane:
                    EditorGUILayout.HelpBox("设了跟随目标时，整条轨迹跟着它移动。没设时轨迹停在世界坐标里。有注视目标时对准该点。", MessageType.None);
                    if (GUILayout.Button("从跟随目标读取起点"))
                    {
                        if (ctx.Follow != null)
                        {
                            p.A = Vector3.zero;
                            CineShotSceneEditor.WriteRig(ctx, p, "从跟随目标读取摇臂起点");
                        }
                    }
                    break;
                case RigKind.Shoulder:
                    if (Field("肩侧距离", ref p.P0)) CineShotSceneEditor.WriteRig(ctx, p, "调整过肩距离");
                    if (Field("肩高", ref p.P1)) CineShotSceneEditor.WriteRig(ctx, p, "调整过肩高度");
                    if (GUILayout.Button(p.I0 >= 0 ? "当前右肩，点此改左肩" : "当前左肩，点此改右肩"))
                    {
                        p.I0 = p.I0 >= 0 ? -1 : 1;
                        CineShotSceneEditor.WriteRig(ctx, p, "切换左右肩");
                    }
                    break;
                case RigKind.Handheld:
                    if (Field("振幅", ref p.P0)) CineShotSceneEditor.WriteRig(ctx, p, "调整手持振幅");
                    if (Field("频率", ref p.P1)) CineShotSceneEditor.WriteRig(ctx, p, "调整手持频率");
                    break;
                case RigKind.Static:
                    EditorGUILayout.HelpBox("静态机位用 Scene 里的位移手柄改偏移。", MessageType.None);
                    break;
                case RigKind.SplineDolly:
                    EditorGUILayout.HelpBox("行程由片段时长决定，从第一个控制点走到最后一个。控制点在 Scene 里拖。", MessageType.None);
                    break;
            }

            EditorGUI.BeginChangeCheck();
            float fov = EditorGUILayout.FloatField("视场角", ctx.AuthoredFov);
            if (EditorGUI.EndChangeCheck())
                CineShotSceneEditor.WriteFov(ctx, fov);
        }

        static bool Field(string label, ref float field)
        {
            EditorGUI.BeginChangeCheck();
            float value = EditorGUILayout.FloatField(label, field);
            if (EditorGUI.EndChangeCheck())
            {
                field = value;
                return true;
            }
            return false;
        }
    }

    [MenuEntry("打开镜头配置", 100)]
    sealed class OpenCineShotConfigAction : ClipAction
    {
        public override ActionValidity Validate(IEnumerable<TimelineClip> clips)
        {
            foreach (var clip in clips)
            {
                if (clip != null && clip.asset is CineShotClip)
                    return ActionValidity.Valid;
            }
            return ActionValidity.NotApplicable;
        }

        public override bool Execute(IEnumerable<TimelineClip> clips)
        {
            CineShotClipConfigWindow.Open();
            return true;
        }
    }
}
